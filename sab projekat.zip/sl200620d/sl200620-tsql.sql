USE ProdajaArtikala
go

CREATE PROCEDURE SP_FINAL_PRICE
	@Porudzbina int
AS
BEGIN
	declare @Datum date
	declare @Iznos decimal(10,3)
	declare @Kolicina int
	declare @kursor2 cursor

	/*popust na kolicinu kod kupca*/
	declare @kursor3 cursor
	declare @DatumPor date
	declare @Iznosi decimal(10,3)


	set @kursor3 = cursor for
	select Iznos
	from Porudzbina
	where datediff(day, convert(datetime,Datum), getDate()) < 30

	open @kursor3
	declare @SumaIznosa decimal(10,3)
	set @SumaIznosa = 0		
	fetch next from @kursor3
	into  @Iznosi

	while @@FETCH_STATUS = 0 
		begin
			set @SumaIznosa = @SumaIznosa + @Iznosi
			fetch next from @kursor3
			into  @Iznosi
		end
	close @kursor3
	deallocate @kursor3
				
	declare @KupacPopust int
	set @KupacPopust = 0
	if (@SumaIznosa > 10000) 
		begin
			set @KupacPopust = 2
		end


	set @kursor2 = cursor for
	select A.Idpro
	from ArtikliPorudzbine AP join Artikal A on AP.IdArt = A.IdArt
	where AP.IdPor =  @Porudzbina 

	open @kursor2
	declare @Prodavnica int

	fetch next from @kursor2
	into @Prodavnica

	while @@FETCH_STATUS = 0 
		begin
			/*popust za prodavnice*/
			declare @Popust int
			set @Kolicina = 0
			select @Kolicina 				

			declare @IdArtikla int

			declare @kursor4 cursor

			set @kursor4 = cursor for
			select A.IdArt, AP.Kolicina, A.Cena
			from ArtikliPorudzbine AP join Artikal A on AP.IdArt = A.IdArt
			where AP.IdPor =  @Porudzbina and A.IdPro = @Prodavnica
						

			declare @kolicina1 int
			declare @iznos2 int

			open @kursor4
			fetch next from @kursor4
			into @IdArtikla, @kolicina1, @iznos2
				
			declare @iznosArtikala decimal(10,3)
			declare @KonacanIznos decimal(10,3)

			while @@FETCH_STATUS = 0 
				begin
					select @Popust  = Popust
					from Prodavnica
					where @Prodavnica = IdPro

					if (@Popust = 0)
						begin
							set @iznosArtikala = @kolicina1 * @iznos2
						end
					else
						begin
							set @iznosArtikala = (@kolicina1 * @iznos2) * (1-@Popust/100)
						end
					set @KonacanIznos = @KonacanIznos + @iznosArtikala

					fetch next from @kursor4
					into @IdArtikla, @kolicina1, @iznos2
				end

			close @kursor4
			deallocate @kursor4



			fetch next from @kursor2
			into @Prodavnica


		end
		close @kursor2
		deallocate @kursor2
		
		if(@KupacPopust >0) 
			begin
				set @KonacanIznos = @KonacanIznos * (1- @KupacPopust/100)
			end

END
GO


/*==========================================*/



/*Dodavanje gradova*/

INSERT INTO Grad (Naziv) values ('Beograd')
go
INSERT INTO Grad (Naziv) values ('Novi Sad')
go
INSERT INTO Grad (Naziv) values ('Nis')
go
INSERT INTO Grad (Naziv) values ('Kraljevo')
go
INSERT INTO Grad (Naziv) values ('Subotica')
go
INSERT INTO Grad (Naziv) values ('Paracin')
go
INSERT INTO Grad (Naziv) values ('Valjevo')
go
INSERT INTO Grad (Naziv) values ('Krusevac')
go
INSERT INTO Grad (Naziv) values ('Uzice')
go
INSERT INTO Grad (Naziv) values ('Cacak')
go
INSERT INTO Grad (Naziv) values ('Leskovac')
go
INSERT INTO Grad (Naziv) values ('Vranje')
go
INSERT INTO Grad (Naziv) values ('Zrenjanin')
go
INSERT INTO Grad (Naziv) values ('Jagodina')
go
INSERT INTO Grad (Naziv) values ('Bor')
go
INSERT INTO Grad (Naziv) values ('Kragujevac')
go


/*Dodavanje linija*/

INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(1,2,2)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(1,13,2)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(1,7,3)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(1,14,4)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(15,14,3)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(15,6,5)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(2,5,3)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(2,13,3)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(3,11,4)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(3,12,5)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(3,6,6)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(4,7,4)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(4,8,3)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(4,10,4)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(4,16,3)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(5,13,4)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(6,8,3)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(6,14,3)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(6,16,6)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(7,8,5)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(7,10,3)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(7,16,5)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(8,14,6)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(8,3,4)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(8,16,4)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(9,10,4)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(10,16,4)
GO
INSERT INTO [dbo].[Linija] ([GradA],[GradB],[Razdaljina]) VALUES(11,12,4)
GO

/*Dodavanje prodavnica */
INSERT INTO [dbo].[Prodavnica] ([IdGra],[Stanje],[Naziv]) VALUES (1,0,'Tehnomanija')
GO
INSERT INTO [dbo].[Prodavnica] ([IdGra],[Stanje],[Naziv]) VALUES (1,0,'Laguna')
GO
INSERT INTO [dbo].[Prodavnica] ([IdGra],[Stanje],[Naziv]) VALUES (1,0,'Vulkan')
GO
INSERT INTO [dbo].[Prodavnica] ([IdGra],[Stanje],[Naziv]) VALUES (16,0,'Gigatron')
GO
INSERT INTO [dbo].[Prodavnica] ([IdGra],[Stanje],[Naziv]) VALUES (1,0, 'Tehnomedija')
GO
INSERT INTO [dbo].[Prodavnica] ([IdGra],[Stanje],[Naziv]) VALUES (13,0, 'Maxi')
GO
INSERT INTO [dbo].[Prodavnica] ([IdGra],[Stanje],[Naziv]) VALUES (1,0,'ComputerLand')
GO
INSERT INTO [dbo].[Prodavnica] ([IdGra],[Stanje],[Naziv]) VALUES (2,0,'Sephora')
GO
INSERT INTO [dbo].[Prodavnica] ([IdGra],[Stanje],[Naziv]) VALUES (8,0,'DM')
GO
INSERT INTO [dbo].[Prodavnica] ([IdGra],[Stanje],[Naziv]) VALUES (16,0,'Lilly')
GO
INSERT INTO [dbo].[Prodavnica] ([IdGra],[Stanje],[Naziv]) VALUES (7, 0, 'CT Shop')
GO

/*dodavanje kupaca*/

INSERT INTO [dbo].[Kupac] ([Ime],[IdGra],[Stanje]) VALUES ('Luka', 1, 0)
GO
INSERT INTO [dbo].[Kupac] ([Ime],[IdGra],[Stanje]) VALUES ('Luka',3,0)
GO
INSERT INTO [dbo].[Kupac] ([Ime],[IdGra],[Stanje])VALUES ('Marko',  5,0)
GO
INSERT INTO [dbo].[Kupac] ([Ime],[IdGra],[Stanje]) VALUES ('Nikola',  7,0)
GO
INSERT INTO [dbo].[Kupac] ([Ime],[IdGra],[Stanje]) VALUES ('Marko',  9,0)
GO
INSERT INTO [dbo].[Kupac] ([Ime],[IdGra],[Stanje]) VALUES ('Jovana',  11,0)
GO
INSERT INTO [dbo].[Kupac] ([Ime],[IdGra],[Stanje]) VALUES ('Ana',  12,0)
GO
INSERT INTO [dbo].[Kupac] ([Ime],[IdGra],[Stanje]) VALUES ('Ana',  6,0)
GO
INSERT INTO [dbo].[Kupac] ([Ime],[IdGra],[Stanje])  VALUES ('Marija',  4,0)
GO


/*dodavanje artikala*/



INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (100, 5, 1, 'Mis1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (200, 2, 1, 'Tastatura1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (50, 1, 1, 'Mis2')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (110, 5, 2, 'Mis1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (35, 5, 3, 'Mis2')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (100, 5, 4, 'Mis1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (100, 5, 5, 'Mis1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (200, 2, 6, 'Tastatura1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (50, 1, 7, 'Mis2')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (110, 5, 8, 'Mis1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (35, 5, 9, 'Mis2')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (100, 5, 10, 'Mis1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (100, 5, 11, 'Mis1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (200, 2, 12, 'Tastatura1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (50, 1, 13, 'Mis2')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (110, 5, 24, 'Mis1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (35, 5, 14, 'Mis2')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (100, 5, 15, 'Mis1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (220, 5, 4, 'Tastatura3')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (200, 2, 16, 'Tastatura1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (50, 1, 17, 'Tastatura2')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (110, 5, 2, 'Tastatura3')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (45, 5, 3, 'Tastatura2')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (240, 5, 4, 'Tastatura1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (35, 5, 2, 'Mis4')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (100, 6, 2, 'Mis1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (220, 1, 2, 'Tastatura1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (200, 2, 3, 'Tastatura1')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (50, 1, 3, 'Tastatura4')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (110, 3, 3, 'Tastatura3')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (45, 2, 4, 'Tastatura2')
GO
INSERT INTO [dbo].[Artikal]([Cena],[Kolicina],[IdPro],[Naziv]) VALUES (240, 2, 4, 'Tastatura4')
GO























