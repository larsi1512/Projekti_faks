
DROP TABLE [ArtikliPorudzbine]
go

DROP TABLE [Artikal]
go

DROP TABLE [Naplata]
go

DROP TABLE [Transakcija]
go

DROP TABLE [Porudzbina]
go

DROP TABLE [Kupac]
go

DROP TABLE [Prodavnica]
go

DROP TABLE [Linija]
go

DROP TABLE [Grad]
go

CREATE TABLE [Artikal]
( 
	[IdArt]              INT  IDENTITY  NOT NULL ,
	[Cena]               decimal(10,3)  NOT NULL 
	CONSTRAINT [VeceIliJednakoNula_876049896]
		CHECK  ( Cena >= 0 ),
	[Kolicina]           INT  NULL ,
	[IdPro]              INT  NOT NULL ,
	[Naziv]              varchar(100)  NULL 
)
go

CREATE TABLE [ArtikliPorudzbine]
( 
	[IdPor]              INT  NOT NULL ,
	[IdArt]              INT  NOT NULL ,
	[Kolicina]           integer  NOT NULL 
)
go

CREATE TABLE [Grad]
( 
	[IdGra]              INT  IDENTITY  NOT NULL ,
	[Naziv]              char varying(100)  NULL 
)
go

CREATE TABLE [Kupac]
( 
	[IdKup]              INT  IDENTITY  NOT NULL ,
	[Ime]                char varying(100)  NOT NULL ,
	[IdGra]              INT  NULL ,
	[Stanje]             int  NULL 
)
go

CREATE TABLE [Linija]
( 
	[GradA]              INT  NOT NULL ,
	[GradB]              INT  NOT NULL ,
	[Razdaljina]         INT  NULL 
	CONSTRAINT [VeceIliJednakoNula_438270111]
		CHECK  ( Razdaljina >= 0 ),
	[IdLin]              int  IDENTITY  NOT NULL 
)
go

CREATE TABLE [Naplata]
( 
	[Iznos]              decimal(10,3)  NULL ,
	[IdPor]              INT  NOT NULL ,
	[Datum]              char(18)  NULL ,
	[IdNap]              int  NOT NULL 
)
go

CREATE TABLE [Porudzbina]
( 
	[IdPor]              INT  IDENTITY  NOT NULL ,
	[IdKup]              INT  NOT NULL ,
	[Datum]              datetime  NULL ,
	[Iznos]              decimal(10,3)  NULL 
	CONSTRAINT [VeceIliJednakoNula_1142437528]
		CHECK  ( Iznos >= 0 ),
	[Status]             char varying(100)  NULL 
	CONSTRAINT [StatusPorudzbine_579216010]
		CHECK  ( [Status]='arrived' OR [Status]='created' OR [Status]='sent' ),
	[IdGra]              INT  NULL ,
	[DatumPrijema]       datetime  NULL 
)
go

CREATE TABLE [Prodavnica]
( 
	[IdPro]              INT  IDENTITY  NOT NULL ,
	[IdGra]              INT  NOT NULL ,
	[Stanje]             decimal(10,3)  NULL ,
	[Naziv]              varchar(100)  NULL ,
	[Popust]             integer  NULL 
)
go

CREATE TABLE [Transakcija]
( 
	[IdTra]              INT  IDENTITY  NOT NULL ,
	[Iznos]              decimal(10,3)  NOT NULL ,
	[IdPro]              INT  NOT NULL ,
	[IdPor]              INT  NOT NULL 
)
go

ALTER TABLE [Artikal]
	ADD CONSTRAINT [XPKArtikal] PRIMARY KEY  NONCLUSTERED ([IdArt] ASC)
go

ALTER TABLE [ArtikliPorudzbine]
	ADD CONSTRAINT [XPKArtikliPorudzbine] PRIMARY KEY  CLUSTERED ([IdPor] ASC,[IdArt] ASC)
go

ALTER TABLE [Grad]
	ADD CONSTRAINT [XPKGrad] PRIMARY KEY  NONCLUSTERED ([IdGra] ASC)
go

ALTER TABLE [Grad]
	ADD CONSTRAINT [XAK1NazivGrada] UNIQUE ([Naziv]  ASC)
go

ALTER TABLE [Kupac]
	ADD CONSTRAINT [XPKKupac] PRIMARY KEY  NONCLUSTERED ([IdKup] ASC)
go

ALTER TABLE [Linija]
	ADD CONSTRAINT [XPKLinija] PRIMARY KEY  NONCLUSTERED ([IdLin] ASC,[GradA] ASC,[GradB] ASC)
go

ALTER TABLE [Naplata]
	ADD CONSTRAINT [XPKNaplata] PRIMARY KEY  CLUSTERED ([IdNap] ASC)
go

ALTER TABLE [Porudzbina]
	ADD CONSTRAINT [XPKPorudzbina] PRIMARY KEY  NONCLUSTERED ([IdPor] ASC)
go

ALTER TABLE [Prodavnica]
	ADD CONSTRAINT [XPKProdavnica] PRIMARY KEY  NONCLUSTERED ([IdPro] ASC)
go

ALTER TABLE [Prodavnica]
	ADD CONSTRAINT [XAK1Prodavnica] UNIQUE ([Naziv]  ASC)
go

ALTER TABLE [Transakcija]
	ADD CONSTRAINT [XPKTransakcija] PRIMARY KEY  CLUSTERED ([IdTra] ASC)
go


ALTER TABLE [Artikal]
	ADD CONSTRAINT [R_3] FOREIGN KEY ([IdPro]) REFERENCES [Prodavnica]([IdPro])
		ON DELETE NO ACTION
		ON UPDATE CASCADE
go


ALTER TABLE [ArtikliPorudzbine]
	ADD CONSTRAINT [R_24] FOREIGN KEY ([IdPor]) REFERENCES [Porudzbina]([IdPor])
		ON DELETE NO ACTION
		ON UPDATE CASCADE
go

ALTER TABLE [ArtikliPorudzbine]
	ADD CONSTRAINT [R_25] FOREIGN KEY ([IdArt]) REFERENCES [Artikal]([IdArt])
		ON DELETE NO ACTION
		ON UPDATE CASCADE
go


ALTER TABLE [Kupac]
	ADD CONSTRAINT [R_23] FOREIGN KEY ([IdGra]) REFERENCES [Grad]([IdGra])
		ON DELETE NO ACTION
		ON UPDATE CASCADE
go


ALTER TABLE [Linija]
	ADD CONSTRAINT [GradA] FOREIGN KEY ([GradA]) REFERENCES [Grad]([IdGra])
		ON DELETE NO ACTION
		ON UPDATE CASCADE
go

ALTER TABLE [Linija]
	ADD CONSTRAINT [R_11] FOREIGN KEY ([GradB]) REFERENCES [Grad]([IdGra])
		ON DELETE NO ACTION
		ON UPDATE CASCADE
go


ALTER TABLE [Naplata]
	ADD CONSTRAINT [R_28] FOREIGN KEY ([IdPor]) REFERENCES [Porudzbina]([IdPor])
		ON DELETE NO ACTION
		ON UPDATE CASCADE
go


ALTER TABLE [Porudzbina]
	ADD CONSTRAINT [R_2] FOREIGN KEY ([IdKup]) REFERENCES [Kupac]([IdKup])
		ON DELETE NO ACTION
		ON UPDATE CASCADE
go

ALTER TABLE [Porudzbina]
	ADD CONSTRAINT [R_31] FOREIGN KEY ([IdGra]) REFERENCES [Grad]([IdGra])
		ON DELETE NO ACTION
		ON UPDATE CASCADE
go


ALTER TABLE [Prodavnica]
	ADD CONSTRAINT [R_1] FOREIGN KEY ([IdGra]) REFERENCES [Grad]([IdGra])
		ON DELETE NO ACTION
		ON UPDATE CASCADE
go


ALTER TABLE [Transakcija]
	ADD CONSTRAINT [R_29] FOREIGN KEY ([IdPro]) REFERENCES [Prodavnica]([IdPro])
		ON DELETE NO ACTION
		ON UPDATE CASCADE
go

ALTER TABLE [Transakcija]
	ADD CONSTRAINT [R_30] FOREIGN KEY ([IdPor]) REFERENCES [Porudzbina]([IdPor])
		ON DELETE NO ACTION
		ON UPDATE CASCADE
go
