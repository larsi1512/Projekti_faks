/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.CityOperations;

/**
 *
 * @author LARA
 */
public class sl200620_CityOperations implements CityOperations {
    
    private  Connection conn=DB.getInstance().getConnection();
    
    @Override
    public int createCity(String string) {
        String query = "insert into Grad(Naziv) values(?)";
        try ( PreparedStatement ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {
            ps.setString(1, string);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return (rs.getInt(1));
            }
    }   catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
        return -1;
        
    }

    @Override
    public  List<Integer> getCities(){
        List<Integer> lista = new ArrayList<>();
        try (PreparedStatement ps1 =  conn.prepareStatement("select IdGra from Grad");) {
                try(ResultSet rs1 = ps1.executeQuery();) {
                    while (rs1.next()) {
                        lista.add(rs1.getInt(1));
                    }
                }
                catch (SQLException ex) {
                    Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                    return null;
                }
            
            } catch (SQLException ex) {
                Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
        return lista;
        
    }

    @Override
    public int connectCities(int i, int i1, int i2){
        String query = "insert into Linija(GradA, GradB, Razdaljina) values(?,?,?)";
        try ( PreparedStatement ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {

            ps.setInt(1, i);
            ps.setInt(2, i1);
            ps.setInt(3, i2);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return (rs.getInt(1));
            }
    }   catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
        return -1;
        
    }

    @Override
    public List<Integer> getConnectedCities(int i) {
        List<Integer> lista = new ArrayList<>();
        try (PreparedStatement ps1 =  conn.prepareStatement("select GradB from Linija where GradA = ?");) {
                ps1.setInt(1, i);
                try(ResultSet rs1 = ps1.executeQuery();) {
                    while (rs1.next()) {
                        lista.add(rs1.getInt(1));
                    }
                
                }
                catch (SQLException ex) {
                    Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                    return null;
                }
            
            } catch (SQLException ex) {
                Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                return null;
        }
        try (PreparedStatement ps2 =  conn.prepareStatement("select GradA from Linija where GradB = ?");) {
            ps2.setInt(1, i);
            try(ResultSet rs2 = ps2.executeQuery();) {
                while (rs2.next()) {
                    lista.add(rs2.getInt(1));
                }

            }
            catch (SQLException ex) {
                Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }

        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return lista;
        
    }

    @Override
    public List<Integer> getShops(int i) {
        List<Integer> lista = new ArrayList<>();
        try (PreparedStatement ps1 =  conn.prepareStatement("select IdPro from Prodavnica where IdGra = ?");) {
            ps1.setInt(1, i);
            try(ResultSet rs1 = ps1.executeQuery();) {
                while (rs1.next()) {
                    lista.add(rs1.getInt(1));
                }

            }
            catch (SQLException ex) {
                Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }

        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return lista;
        
    }
    
//    public static void main(String[] args) {
//        int createCity = createCity("Ruma");
//        System.out.println("GradId" + createCity);
//        List<Integer> cities = getCities();
//        System.out.println(cities);
//        int connected = connectCities(2,17,1);
//        System.out.println("Linija br " + connected);
//        List<Integer> connectedCities = getConnectedCities(1);
//        System.out.println("Sa Gradom1 postoje linije" + connectedCities);
//
//        List<Integer> shops = getShops(1);
//        System.out.println("Radnje u Gradu1 su " + shops);
//        
//    }
}
