

package rs.etf.sab.student;

import rs.etf.sab.tests.TestHandler;
import rs.etf.sab.tests.TestRunner;
import rs.etf.sab.operations.*;
import org.junit.Test;

import java.util.Calendar;

public class StudentMain {

    public static void main(String[] args) {

        ArticleOperations articleOperations = new sl200620_ArticleOperations(); // Change this for your implementation (points will be negative if interfaces are not implemented).
        BuyerOperations buyerOperations = new sl200620_BuyerOperations();
        CityOperations cityOperations = new sl200620_CityOperations();
        GeneralOperations generalOperations = new sl200620_GeneralOperations();
        OrderOperations orderOperations = new sl200620_OrderOperations();
        ShopOperations shopOperations = new sl200620_ShopOperations();
        TransactionOperations transactionOperations = new sl200620_TransactionOperations();

        TestHandler.createInstance(
                articleOperations,
                buyerOperations,
                cityOperations,
                generalOperations,
                orderOperations,
                shopOperations,
                transactionOperations
        );

        TestRunner.runTests();
    }
}
