/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.ArticleOperations;

/**
 *
 * @author LARA
 */
public class sl200620_ArticleOperations  implements ArticleOperations{
    private Connection conn=DB.getInstance().getConnection();

    /**
     *
     * @param i
     * @param string
     * @param i1
     * @return
     */
    
    
    @Override
    public int createArticle(int i, String string, int i1) {
        String query = "insert into Artikal(Cena, Kolicina, IdPro, Naziv) values(?,?,?,?)";
        try ( PreparedStatement ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {
            ps.setInt(1, i1);
            ps.setInt(2,0);
            ps.setInt(3, i);
            ps.setString(4, string);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return (rs.getInt(1));
            }
            else {
                return -1;
            }
    }   catch (SQLException ex) {
            Logger.getLogger(sl200620_ArticleOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }

        
    }
    


    
}
