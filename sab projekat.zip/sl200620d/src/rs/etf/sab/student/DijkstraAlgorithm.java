/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;

/**
 *
 * @author LARA
 */
import java.util.*;

public class DijkstraAlgorithm {
        
        
    public static List<Integer> shortestPath(Map<Integer, Map<Integer, Integer>> graph, int start, int end) {
        Map<Integer, Integer> distances = new HashMap<>();
        for (int node : graph.keySet()) {
            distances.put(node, Integer.MAX_VALUE);
        }
        distances.put(start, 0);

        PriorityQueue<int[]> queue = new PriorityQueue<>(Comparator.comparingInt(arr -> arr[1]));
        queue.offer(new int[]{start, 0});

        Set<Integer> visited = new HashSet<>();

        while (!queue.isEmpty()) {
            int[] current = queue.poll();
            int currentNode = current[0];
            int currentDistance = current[1];

            visited.add(currentNode);

            if (currentNode == end) {
                break;
            }

            Map<Integer, Integer> neighbors = graph.get(currentNode);
            if (neighbors != null) {
                for (Map.Entry<Integer, Integer> entry : neighbors.entrySet()) {
                    int neighbor = entry.getKey();
                    int weight = entry.getValue();

                    if (!visited.contains(neighbor)) {
                        int distance = currentDistance + weight;
                        if (distance < distances.get(neighbor)) {
                            distances.put(neighbor, distance);
                            queue.offer(new int[]{neighbor, distance});
                        }
                    }
                }
            }
        }

        if (distances.get(end) == Integer.MAX_VALUE) {
            return null;  // No path exists
        }

        // Backtrack to find the shortest path
        List<Integer> path = new ArrayList<>();
        int node = end;
        while (node != start) {
            path.add(node);
            Map<Integer, Integer> neighbors = graph.get(node);
            if (neighbors != null) {
                for (Map.Entry<Integer, Integer> entry : neighbors.entrySet()) {
                    int neighbor = entry.getKey();
                    int weight = entry.getValue();
                    if (distances.get(node) == distances.get(neighbor) + weight) {
                        node = neighbor;
                        break;
                    }
                }
            }
        }
        path.add(start);
        Collections.reverse(path);
        return path;
    }

    public static void main(String[] args) {
        // Example usage
        Map<Integer, Map<Integer, Integer>> graph = new HashMap<>();
        graph.put(0, new HashMap<>());
        graph.put(1, new HashMap<>());
        graph.put(2, new HashMap<>());
        graph.put(3, new HashMap<>());
        graph.put(4, new HashMap<>());
        graph.get(0).put(1, 4);
        graph.get(0).put(2, 2);
        graph.get(1).put(3, 2);
        graph.get(2).put(1, 1);
        graph.get(2).put(3, 5);
        graph.get(3).put(4, 3);

        int startNode = 0;
        int endNode = 4;
        List<Integer> shortestPath = shortestPath(graph, startNode, endNode);
        if (shortestPath != null) {
            System.out.println("Shortest path from " + startNode + " to " + endNode + ": " + shortestPath);
        } else {
            System.out.println("No path exists from " + startNode + " to " + endNode);
        }
    }
}
