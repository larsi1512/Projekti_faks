/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.TransactionOperations;

/**
 *
 * @author LARA
 */
public class sl200620_TransactionOperations implements TransactionOperations {
    private  Connection conn=DB.getInstance().getConnection();
    
    @Override
    public BigDecimal getBuyerTransactionsAmmount(int p0) {
        BigDecimal bd = new BigDecimal(0);
        try (
            PreparedStatement ps =  conn.prepareStatement("select Iznos from Porudzbina\n" +
                                                    "where IdKup = ?");) {
            ps.setInt(1, p0);
            try(
            ResultSet rs = ps.executeQuery();) {
                if (rs.next()) {
                    bd.add(rs.getBigDecimal(1));
                    while (rs.next()) {
                        bd.add(rs.getBigDecimal(1));
                    }
                }
                else {
                    return bd.valueOf(1);
                }
            }
            catch (SQLException ex) {
                return bd;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        return bd;
    }

    @Override
    public BigDecimal getShopTransactionsAmmount(int p0) {
        BigDecimal bd = new BigDecimal(0);
        try (
            PreparedStatement ps =  conn.prepareStatement("select Stanje from Prodavnica\n" +
                                                    "where IdPro = ?");) {
            ps.setInt(1, p0);
            try(
            ResultSet rs = ps.executeQuery();) {
                if (rs.next()) {
                    bd.add(rs.getBigDecimal(1));
                    while (rs.next()) {
                        bd.add(rs.getBigDecimal(1));
                    }
                }
                else {
                    return bd.valueOf(1);
                }
            }
            catch (SQLException ex) {
                return bd;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        return bd;
    }

    @Override
    public List<Integer> getTransationsForBuyer(int p0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getTransactionForBuyersOrder(int p0) {
        try (
            PreparedStatement ps =  conn.prepareStatement("select IdNap from Naplata\n" +
                                                    "where IdPor = ?");) {
            ps.setInt(1, p0);
            try(
            ResultSet rs = ps.executeQuery();) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
                else {
                    return -1;
                }
            }
            catch (SQLException ex) {
                return -1;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
        
    }

    @Override
    public int getTransactionForShopAndOrder(int p0, int p1) {
        try (
            PreparedStatement ps =  conn.prepareStatement("select IdTra from Transakcija\n" +
                                                    "where IdPor = ? and IdPro = ?");) {
            ps.setInt(1, p0);
            ps.setInt(2, p1);
            try(
            ResultSet rs = ps.executeQuery();) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
                else {
                    return -1;
                }
            }
            catch (SQLException ex) {
                return -1;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
    }

    @Override
    public List<Integer> getTransationsForShop(int p0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Calendar getTimeOfExecution(int p0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public BigDecimal getAmmountThatBuyerPayedForOrder(int p0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public BigDecimal getAmmountThatShopRecievedForOrder(int p0, int p1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public BigDecimal getTransactionAmount(int p0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public BigDecimal getSystemProfit() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
