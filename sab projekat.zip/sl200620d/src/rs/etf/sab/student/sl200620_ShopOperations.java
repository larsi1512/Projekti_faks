/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.ShopOperations;

/**
 *
 * @author LARA
 */
public class sl200620_ShopOperations implements ShopOperations{
    
    private Connection conn=DB.getInstance().getConnection();
    
    
    
    @Override
    public int createShop(String string, String string1) {
        
        int IdGrada = 0;
        
        try (
            PreparedStatement ps =  conn.prepareStatement("select IdGra from Grad\n" +
                                                    "where Naziv = ?");) {
            ps.setString(1, string1);
            try(
            ResultSet rs = ps.executeQuery();) {
                if (rs.next()) {
                    IdGrada =  rs.getInt(1);
                }
                else {
                    return -1;
                }
            }
            catch (SQLException ex) {
                return -1;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        String query = "insert into Prodavnica(IdGra, Stanje, Naziv, Popust) values(?,?,?,?)";
        try ( PreparedStatement ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {
            ps.setInt(1, IdGrada);
            ps.setInt(2, 0);
            ps.setString(3, string);
            ps.setInt(4, 0);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return (rs.getInt(1));
            }
    }   catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
        return -1;
    }

    @Override
    public int setCity(int i, String string) {
        String query = "update Prodavnica \n" +
                                "  set IdGra =  (select IdGra\n" +
                                "  from Grad\n" +
                                "  where Naziv = ?)\n" +
                                "  where IdPro = ?";
        try ( PreparedStatement ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {

            ps.setInt(2, i);
            ps.setString(1, string);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
        return -1;
        
    }
    @Override
    public int getCity(int i) {
        try (
            PreparedStatement ps =  conn.prepareStatement("select IdGra from Prodavnica\n" +
                                                    "where IdPro = ?");) {
            ps.setInt(1, i);
            try(
            ResultSet rs = ps.executeQuery();) {
                if (rs.next()) {
                    return rs.getInt("IdGra");
                }
                
            }
            catch (SQLException ex) {
                return -1;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        return -1;
        
    }
    
    @Override
    public int setDiscount(int i, int i1) {
        String query = "update Prodavnica set Popust = ? where IdPro = ?";
        try ( PreparedStatement ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {
            
            ps.setInt(1, i1);
            ps.setInt(2, i);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
        return -1;
        
    }
    @Override
    public  int increaseArticleCount(int i, int i1) {
        int Kolicina = 0;
        try (
            PreparedStatement ps =  conn.prepareStatement("select Kolicina from Artikal\n" +
                                                    "where IdArt = ?");) {
            ps.setInt(1, i);
            try(
            ResultSet rs = ps.executeQuery();) {
                if (rs.next()) {
                    Kolicina = rs.getInt(1);
                }
                else {
                    return -1;
                }
            }
            catch (SQLException ex) {
                return -1;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
       

        String query = "update Artikal set Kolicina = ? where IdArt = ?";
        try ( PreparedStatement ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {
            
            ps.setInt(1, i1+Kolicina);
            ps.setInt(2, i);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return getArticleCount(i);
            }
            else {
                return -1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
        
    }
    
    @Override
    public int getArticleCount(int i) {
        try (
            PreparedStatement ps =  conn.prepareStatement("select Kolicina from Artikal\n" +
                                                    "where IdArt = ?");) {
            ps.setInt(1, i);
            try(
            ResultSet rs = ps.executeQuery();) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
                
            }
            catch (SQLException ex) {
                return -1;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return 0;
        
    }
    @Override
    public List<Integer> getArticles(int i) {
        List<Integer> lista = new ArrayList<>();
        try (
            PreparedStatement ps =  conn.prepareStatement("select IdArt from Artikal\n" +
                                                    "where IdPro = ?");) {
            ps.setInt(1, i);
            try(
            ResultSet rs = ps.executeQuery();) {
                while (rs.next()) {
                    lista.add(rs.getInt(1));
                }
                
            }
            catch (SQLException ex) {
                Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return lista;
    }
    @Override
    public int getDiscount(int i) {
        try (
            PreparedStatement ps =  conn.prepareStatement("select Popust from Prodavnica\n" +
                                                    "where IdPro = ?");) {
            ps.setInt(1, i);
            try(
            ResultSet rs = ps.executeQuery();) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            catch (SQLException ex) {
                    
                Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                return -1;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
        return 0;
        
    }
//    public static void main(String[] args) {
//        int createShop = createShop("Manga", "Kraljevo");
//        System.out.println("Id prodavnice " + createShop);
//        int setCity = setCity(11, "Beograd");
//        System.out.println("Promenjen grad " + setCity);
//        int city = getCity(1);
//        System.out.println("Prodavnica jedan je u gradu " + city);
//        int setDiscount = setDiscount(1, 5);
//        System.out.println("Popust je " + setDiscount);
//        int articleCount = getArticleCount(1);
//        System.out.println("Broj artikala za shop 1 je " + articleCount);
//        int increaseArticleCount = increaseArticleCount(2, 1);
//        System.out.println("Broj artikala za shop 1 je "  + increaseArticleCount);
//        articleCount = getArticleCount(2);
//        System.out.println("Broj artikala za shop 1 je " + articleCount);
//        List<Integer> articles = getArticles(1);
//        System.out.println("Artikli za shop 1 su " + articles);
//        int discount = getDiscount(1);
//        System.out.println("Popust za 1 je " + discount);
//    }
}