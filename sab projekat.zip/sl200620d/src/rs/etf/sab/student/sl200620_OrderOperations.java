/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.OrderOperations;

/**
 *
 * @author LARA
 */
public class sl200620_OrderOperations implements OrderOperations{
    
    private   Connection conn=DB.getInstance().getConnection();
    
    @Override
    public  int addArticle(int i, int i1, int i2) {
        
        int Kolicina = 0;
        try (
            PreparedStatement ps =  conn.prepareStatement("select Kolicina from Artikal\n" +
                                                    "where IdArt = ?");) {
            ps.setInt(1, i1);
            try(
            ResultSet rs = ps.executeQuery();) {
                if (rs.next()) {
                    Kolicina = rs.getInt(1);
                }
                
            }
            catch (SQLException ex) {
                return -1;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
        int kolicinaUKorpi = 0;
        try (
            PreparedStatement ps1 =  conn.prepareStatement("select Kolicina from ArtikliPorudzbine\n" +
                                                    "where IdArt = ? and IdPor =?");) {
            ps1.setInt(1, i1);
            ps1.setInt(2, i);
            try(
            ResultSet rs = ps1.executeQuery();) {
                if (rs.next()) {
                    kolicinaUKorpi = rs.getInt(1);
                }

            }
            catch (SQLException ex) {
                return -1;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
        
        if (Kolicina >= i2) {
            int ok = 0;
            //proveriti da li postoji vec porudzbina za taj artikal i ako postoji samo uvecaj broj
            if(kolicinaUKorpi == 0) {
                String query = "insert into ArtikliPorudzbine(IdPor,IdArt, Kolicina) values(?,?,?)";
                try ( PreparedStatement ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {
                    ps.setInt(1, i);
                    ps.setInt(2, i1);
                    ps.setInt(3, i2);

                    ps.executeUpdate();
                    ResultSet rs = ps.getGeneratedKeys();
                    if (rs.next()) {
                        ok = 1;
                    }
                    //umanjiti kolicinu u tabeli Artikal
                    
                }   catch (SQLException ex) {
                    Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                    return -1;
                }
            }
            else {
                String query = "update ArtikliPorudzbine set Kolicina = ? where IdArt = ? and IdPor = ?";
                try ( PreparedStatement psA = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {
                    psA.setInt(1, i2+kolicinaUKorpi);
                    psA.setInt(2, i1);                 
                    psA.setInt(3, i);
                  
                    psA.executeUpdate();
                    ResultSet rsA = psA.getGeneratedKeys();
                    if (rsA.next()) {
                        ok =1;
                    }
                    
                    
                }   catch (SQLException ex) {
                    Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                    return -1;
                }
            }
            //umanjiti kolicinu u tabeli Artikal
                String query = "update Artikal set Kolicina = ? where IdArt = ?";
                try ( PreparedStatement psB = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {
                    psB.setInt(1, Kolicina-i2);
                    psB.setInt(2, i1);                 

                    psB.executeUpdate();
                    ResultSet rsB = psB.getGeneratedKeys();
                    if (rsB.next()) {
                        if (ok == 1)
                            return (i2+kolicinaUKorpi);
                        else {
                            System.err.println("Greska");
                            return -1;
                        }
                    }
                    
                    
                }   catch (SQLException ex) {
                    Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                    return -1;
                }
            
            return 0;
        }
        else {
            System.out.println("Stanje " + Kolicina + " a trazeno je " + i2);
            return -1;
        }
 
    }

    @Override
    public  int removeArticle(int i, int i1) {
        String query = "delete from  ArtikliPorudzbine where IdArt = ? and IdPor = ?";
        try ( PreparedStatement psA = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {
            psA.setInt(1, i1);                 
            psA.setInt(2, i);

            psA.executeUpdate();
            ResultSet rsA = psA.getGeneratedKeys();
            if (rsA.next()) {
                return 1;
            }
        }   catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }

        return 0;
        
    }
    @Override
    public  List<Integer> getItems(int i) {
        List<Integer> lista = new ArrayList<>();
        try (
            PreparedStatement ps =  conn.prepareStatement("select IdArt from ArtikliPorudzbine\n" +
                                                    "where IdPor = ?");) {
            ps.setInt(1, i);
            try(
            ResultSet rs = ps.executeQuery();) {
                while (rs.next()) {
                    lista.add(rs.getInt(1));
                }
                
            }
            catch (SQLException ex) {
                Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return lista;
        
    }

    @Override
    public int completeOrder(int i) {
        String query = "update Porudzbina set Status = ? where IdPor = ?";
        try ( PreparedStatement psB = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {

            psB.setInt(2, i);                 
            psB.setString(1, "sent");
            psB.executeUpdate();
            ResultSet rsB = psB.getGeneratedKeys();
            if (rsB.next()) {
                return 1;
            }

        }   catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
        return -1;
    }

    @Override
    public BigDecimal getFinalPrice(int i) {
        return null;
        
    }

    @Override
    public BigDecimal getDiscountSum(int i) {
        return null;
        
    }
    @Override
    public  String getState(int i) {
        try (
            PreparedStatement ps1 =  conn.prepareStatement("select Stanje from Porudzbina\n" +
                                                    "where IdPor =?");) {
            ps1.setInt(1, i);
            try(
            ResultSet rs = ps1.executeQuery();) {
                if (rs.next()) {
                    return ("created");
                }
               

            }
            catch (SQLException ex) {
                return "created";
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return "created";
        
    }
    @Override
    public Calendar getSentTime(int i) {
        Calendar c = Calendar.getInstance();
        try (
            PreparedStatement ps1 =  conn.prepareStatement("select Datum from Porudzbina\n" +
                                                            "where IdPor =?");) {
            ps1.setInt(1, i);
            try(
            ResultSet rs = ps1.executeQuery();) {
                if (rs.next()) {
                    Date date = rs.getDate(1);
                    c.setTime(date);
                    return c;
                }

            }
            catch (SQLException ex) {
                return null;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return null;
        
    }
    @Override
    public Calendar getRecievedTime(int i) {
        Calendar c = Calendar.getInstance();
        try (
            PreparedStatement ps1 =  conn.prepareStatement("select DatumPrijema from Porudzbina\n" +
                                                            "where IdPor =?");) {
            ps1.setInt(1, i);
            try(
            ResultSet rs = ps1.executeQuery();) {
                if (rs.next()) {
                    Date date = rs.getDate(1);
                    c.setTime(date);
                    return c;
                }

            }
            catch (SQLException ex) {
                return null;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return null;
        
    }
    @Override
    public int getBuyer(int i) {
        try (
            PreparedStatement ps1 =  conn.prepareStatement("select IdKup from Porudzbina\n" +
                                                            "where IdPor =?");) {
            ps1.setInt(1, i);
            try(
            ResultSet rs = ps1.executeQuery();) {
                if (rs.next()) {
                    return (rs.getInt(1));
                }

            }
            catch (SQLException ex) {
                return -1;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
        return -1;
    }
    
    
    @Override
    public int getLocation(int i) {
        try (
            PreparedStatement ps1 =  conn.prepareStatement("select IdGra from Porudzbina\n" +
                                                            "where IdPor =?");) {
            ps1.setInt(1, i);
            try(
            ResultSet rs = ps1.executeQuery();) {
                if (rs.next()) {
                    return (rs.getInt(1));
                }
                else {
                    return -1;
                }

            }
            catch (SQLException ex) {
                return -1;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
        
    }
    
    

}
