/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.GeneralOperations;

/**
 *
 * @author LARA
 */
public class sl200620_GeneralOperations implements GeneralOperations {
    private  Connection conn=DB.getInstance().getConnection();
    
    private Calendar c = Calendar.getInstance();
    @Override
    public void setInitialTime(Calendar p0) {
        c.setTime(p0.getTime());
        
    }

    @Override
    public Calendar time(int p0) {
        c.add(Calendar.DAY_OF_MONTH, p0);
        return c;
    }

    @Override
    public Calendar getCurrentTime() {
        return c;
    }

    @Override
    public void eraseAll() {
        String query = "DELETE FROM ArtikliPorudzbine\n" +
                        "      WHERE 1=1\n" +
                        "Delete From Artikal\n" +
                        " where 1=1\n" +
                        " delete from Linija\n" +
                        " where 1=1\n" +
                        " delete from Naplata\n" +
                        " where 1=1\n" +
                        " delete from Transakcija\n" +
                        " where 1=1\n" +
                        " Delete from Prodavnica\n" +
                        " where 1=1\n" +
                        " delete from Porudzbina\n" +
                        " where 1=1\n" +
                        " Delete from Kupac\n" +
                        " where 1=1\n" +
                        " delete from Grad \n" +
                        " where 1=1 ";
        try ( PreparedStatement ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
