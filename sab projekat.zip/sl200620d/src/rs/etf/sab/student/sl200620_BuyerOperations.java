/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.BuyerOperations;


/**
 *
 * @author LARA
 */
public class sl200620_BuyerOperations  implements BuyerOperations{
    
    private  Connection conn=DB.getInstance().getConnection();

    
    @Override    
    public  int createBuyer(String string, int i) {
        String query = "insert into Kupac(Ime, IdGra, Stanje) values(?,?,?)";
        try ( PreparedStatement ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {
            ps.setString(1, string);
            ps.setInt(2, i);
            ps.setInt(3, 0);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return (rs.getInt(1));
            }
    }   catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
        return -1;
    }
    
    @Override
    public  int setCity(int i, int i1) {
        String query = "update Kupac set IdGra = ? where IdKup = ?";
        try ( PreparedStatement ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {

            ps.setInt(2, i);
            ps.setInt(1, i1);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
        return -1;
        
    }
    @Override
    public  int getCity(int i) {
        try (
            PreparedStatement ps =  conn.prepareStatement("select IdGra from Kupac\n" +
                                                    "where IdKup = ?");) {
            ps.setInt(1, i);
            try(
            ResultSet rs = ps.executeQuery();) {
                if (rs.next()) {
                    return rs.getInt("IdGra");
                }
                
            }
            catch (SQLException ex) {
                return -1;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        return -1;
        
    }
    @Override
    public  BigDecimal increaseCredit(int i, BigDecimal bd) {
        String query = "update Kupac set Stanje = ? where IdKup = ?";
        BigDecimal Stanje1 = null;
        try ( PreparedStatement ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {
            
            try (PreparedStatement ps1 =  conn.prepareStatement("select Stanje from Kupac\n" +
                                                    "where IdKup = ?");) {
                ps1.setInt(1, i);
                try(ResultSet rs1 = ps1.executeQuery();) {
                    if (rs1.next()) {
                        Stanje1  = rs1.getBigDecimal(1).setScale(3);
                    }
                
                }
                catch (SQLException ex) {
                    Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                }
            
            } catch (SQLException ex) {
                Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            }


            bd.add(Stanje1).setScale(3);
            ps.setInt(2, i);
            ps.setDouble(1, bd.doubleValue());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                try (PreparedStatement ps2 =  conn.prepareStatement("select Stanje from Kupac\n" +
                                                        "where IdKup = ?");) {
                    ps2.setInt(1, i);
                    try(ResultSet rs2 = ps2.executeQuery();) {
                        if (rs2.next()) {
                            double Stanje2 = rs2.getDouble(1);
                            return bd;
                        }

                    }
                    catch (SQLException ex) {
                        Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                    }

                } catch (SQLException ex) {
                    Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
    }   catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

        
    
        
    }
    @Override
    public  int createOrder(int i) {
        String query = "insert into Porudzbina(IdKup,Datum, Iznos, Status) values(?,getDate(),0, 'created')";
        try ( PreparedStatement ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);) {

            ps.setInt(1, i);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return (rs.getInt(1));
            }
    }   catch (SQLException ex) {
            Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
        return -1;
        
    }

    @Override
    public  List<Integer> getOrders(int i) {
        List<Integer> lista = new ArrayList<>();
        try (PreparedStatement ps1 =  conn.prepareStatement("select IdPor from Porudzbina\n" +
                                                    "where IdKup = ?");) {
                ps1.setInt(1, i);
                try(ResultSet rs1 = ps1.executeQuery();) {
                    while (rs1.next()) {
                        lista.add(rs1.getInt(1));
                    }
                
                }
                catch (SQLException ex) {
                    Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                    return null;
                }
            
            } catch (SQLException ex) {
                Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
        return lista;
        
    }


    @Override
    public  BigDecimal getCredit(int i) {
        try (PreparedStatement ps1 =  conn.prepareStatement("select Stanje from Kupac\n" +
                                                    "where IdKup = ?");) {
                ps1.setInt(1, i);
                try(ResultSet rs1 = ps1.executeQuery();) {
                    if (rs1.next()) {
                        return rs1.getBigDecimal(1).setScale(3);
                    }
                
                }
                catch (SQLException ex) {
                    Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                    return null;
                }
            
            } catch (SQLException ex) {
                Logger.getLogger(sl200620_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
        return null;
        
    }
    
//    public static void main(String[] args) {
//        int cr = createBuyer("Milica", 7);
//        int setCity = setCity(10,6);
//        int city = getCity(10);
//        System.out.println(city);
//        BigDecimal b2 = new BigDecimal("15");
//        BigDecimal incCredic= increaseCredit(1,b2);
//        BigDecimal k1 = getCredit(1);
//        BigDecimal k2 = getCredit(10);
//        System.out.println("KREDIT1 " + k1.intValue());
//        System.out.println("KREDIT2 " + k2.intValue());
//        int createOrder = createOrder(1);
//        System.out.println("IdOrder " + createOrder);
//        List<Integer> orders = getOrders(1);
//        if (orders == null) {
//            System.out.println("rs.etf.sab.student.sl200620_BuyerOperations.main()");
//        }
//        System.out.println("Porudzbina"  + orders);
//
//    }
}
